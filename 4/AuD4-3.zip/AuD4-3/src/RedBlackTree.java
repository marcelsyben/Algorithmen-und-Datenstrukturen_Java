public class RedBlackTree {

	private RBTNode nil = new RBTNode(-1,"nil");
	private RBTNode root;

	public RedBlackTree() {
		nil = new RBTNode(-1,"nil");
		nil.color = false;
		nil.left = null;
		nil.right = null;
		root = nil;
	}

	public void insert(int k, String s) {
		// Ordinary Binary Search Insertion
		RBTNode node = new RBTNode(k,s);
		node.parent = null;
		node.left = nil;
		node.right = nil;
		node.color = true; // new node must be red

		RBTNode y = null;
		RBTNode x = this.root;

		while (x != nil) {
			y = x;
			if (node.key < x.key) {
				x = x.left;
			} else {
				x = x.right;
			}
		}

		// y is parent of x
		node.parent = y;
		if (y == null) {
			root = node;
		} else if (node.key < y.key) {
			y.left = node;
		} else {
			y.right = node;
		}

		// if new node is a root node, simply return
		if (node.parent == null){
			node.color = false;
			return;
		}

		// if the grandparent is null, simply return
		if (node.parent.parent == null) {
			return;
		}

		// Fix the tree
		fixInsert(node);
	}

	public String search(int k) {
		return searchTreeHelper(this.root, k).val;
	}

	public int height() {
		return heightRec(root);
	}

	public boolean CheckRB() {
		if (BlackHeight(root) > 0 && redViolation()) {
			return true;
		} else {
			return false;
		}
		
	}

	public void breakRB(){
		root.color = true;
	}


	private void preOrderHelper(RBTNode node) {
		if (node != nil) {
			System.out.print(node.key + " ");
			preOrderHelper(node.left);
			preOrderHelper(node.right);
		} 
	}

	private void inOrderHelper(RBTNode node) {
		if (node != nil) {
			inOrderHelper(node.left);
			System.out.print(node.key + " ");
			inOrderHelper(node.right);
		} 
	}

	private void postOrderHelper(RBTNode node) {
		if (node != nil) {
			postOrderHelper(node.left);
			postOrderHelper(node.right);
			System.out.print(node.key + " ");
		} 
	}

	private RBTNode searchTreeHelper(RBTNode node, int key) {
		if (node == nil || key == node.key) {
			return node;
		}

		if (key < node.key) {
			return searchTreeHelper(node.left, key);
		} 
		return searchTreeHelper(node.right, key);
	}

	// fix the rb tree modified by the delete operation
	private void fixDelete(RBTNode x) {
		RBTNode s;
		while (x != root && x.color == false) {
			if (x == x.parent.left) {
				s = x.parent.right;
				if (s.color == true) {
					// case 3.1
					s.color = false;
					x.parent.color = true;
					leftRotate(x.parent);
					s = x.parent.right;
				}

				if (s.left.color == false && s.right.color == false) {
					// case 3.2
					s.color = true;
					x = x.parent;
				} else {
					if (s.right.color == false) {
						// case 3.3
						s.left.color = false;
						s.color = true;
						rightRotate(s);
						s = x.parent.right;
					} 

					// case 3.4
					s.color = x.parent.color;
					x.parent.color = false;
					s.right.color = false;
					leftRotate(x.parent);
					x = root;
				}
			} else {
				s = x.parent.left;
				if (s.color == true) {
					// case 3.1
					s.color = false;
					x.parent.color = true;
					rightRotate(x.parent);
					s = x.parent.left;
				}

				if (s.right.color == false && s.right.color == false) {
					// case 3.2
					s.color = true;
					x = x.parent;
				} else {
					if (s.left.color == false) {
						// case 3.3
						s.right.color = false;
						s.color = true;
						leftRotate(s);
						s = x.parent.left;
					} 

					// case 3.4
					s.color = x.parent.color;
					x.parent.color = false;
					s.left.color = false;
					rightRotate(x.parent);
					x = root;
				}
			} 
		}
		x.color = false;
	}


	private void rbTransplant(RBTNode u, RBTNode v){
		if (u.parent == null) {
			root = v;
		} else if (u == u.parent.left){
			u.parent.left = v;
		} else {
			u.parent.right = v;
		}
		v.parent = u.parent;
	}

	private void deleteNodeHelper(RBTNode node, int key) {
		// find the node containing key
		RBTNode z = nil;
		RBTNode x, y;
		while (node != nil){
			if (node.key == key) {
				z = node;
			}

			if (node.key <= key) {
				node = node.right;
			} else {
				node = node.left;
			}
		}

		if (z == nil) {
			System.out.println("Couldn't find key in the tree");
			return;
		} 

		y = z;
		boolean yOriginalColor = y.color;
		if (z.left == nil) {
			x = z.right;
			rbTransplant(z, z.right);
		} else if (z.right == nil) {
			x = z.left;
			rbTransplant(z, z.left);
		} else {
			y = minimum(z.right);
			yOriginalColor = y.color;
			x = y.right;
			if (y.parent == z) {
				x.parent = y;
			} else {
				rbTransplant(y, y.right);
				y.right = z.right;
				y.right.parent = y;
			}

			rbTransplant(z, y);
			y.left = z.left;
			y.left.parent = y;
			y.color = z.color;
		}
		if (yOriginalColor == false) {
			fixDelete(x);
		}
	}
	
	// fix the red-black tree
	private void fixInsert(RBTNode k){
		RBTNode u;
		while (k.parent.color == true) {
			if (k.parent == k.parent.parent.right) {
				u = k.parent.parent.left; // uncle
				if (u.color == true) {
					// case 3.1
					u.color = false;
					k.parent.color = false;
					k.parent.parent.color = true;
					k = k.parent.parent;
				} else {
					if (k == k.parent.left) {
						// case 3.2.2
						k = k.parent;
						rightRotate(k);
					}
					// case 3.2.1
					k.parent.color = false;
					k.parent.parent.color = true;
					leftRotate(k.parent.parent);
				}
			} else {
				u = k.parent.parent.right; // uncle

				if (u.color == true) {
					// mirror case 3.1
					u.color = false;
					k.parent.color = false;
					k.parent.parent.color = true;
					k = k.parent.parent;	
				} else {
					if (k == k.parent.right) {
						// mirror case 3.2.2
						k = k.parent;
						leftRotate(k);
					}
					// mirror case 3.2.1
					k.parent.color = false;
					k.parent.parent.color = true;
					rightRotate(k.parent.parent);
				}
			}
			if (k == root) {
				break;
			}
		}
		root.color = false;
	}

	private void printHelper(RBTNode root, String indent, boolean last) {
		// print the tree structure on the screen
	   	if (root != nil) {
		   System.out.print(indent);
		   if (last) {
		      System.out.print("R----");
		      indent += "     ";
		   } else {
		      System.out.print("L----");
		      indent += "|    ";
		   }
            
           String sColor = root.color == true?"RED":"BLACK";
		   System.out.println(root.key + "(" + sColor + ")");
		   printHelper(root.left, indent, false);
		   printHelper(root.right, indent, true);
		}
	}

	// Pre-Order traversal
	// RBTNode.Left Subtree.Right Subtree
	public void preorder() {
		preOrderHelper(this.root);
	}

	// In-Order traversal
	// Left Subtree . RBTNode . Right Subtree
	public void inorder() {
		inOrderHelper(this.root);
	}

	// Post-Order traversal
	// Left Subtree . Right Subtree . RBTNode
	public void postorder() {
		postOrderHelper(this.root);
	}

	// search the tree for the key k
	// and return the corresponding node


	// find the node with the minimum key
	public RBTNode minimum(RBTNode node) {
		while (node.left != nil) {
			node = node.left;
		}
		return node;
	}

	// find the node with the maximum key
	public RBTNode maximum(RBTNode node) {
		while (node.right != nil) {
			node = node.right;
		}
		return node;
	}

	// find the successor of a given node
	public RBTNode successor(RBTNode x) {
		// if the right subtree is not null,
		// the successor is the leftmost node in the
		// right subtree
		if (x.right != nil) {
			return minimum(x.right);
		}

		// else it is the lowest ancestor of x whose
		// left child is also an ancestor of x.
		RBTNode y = x.parent;
		while (y != nil && x == y.right) {
			x = y;
			y = y.parent;
		}
		return y;
	}

	// find the predecessor of a given node
	public RBTNode predecessor(RBTNode x) {
		// if the left subtree is not null,
		// the predecessor is the rightmost node in the 
		// left subtree
		if (x.left != nil) {
			return maximum(x.left);
		}

		RBTNode y = x.parent;
		while (y != nil && x == y.left) {
			x = y;
			y = y.parent;
		}

		return y;
	}

	// rotate left at node x
	public void leftRotate(RBTNode x) {
		RBTNode y = x.right;
		x.right = y.left;
		if (y.left != nil) {
			y.left.parent = x;
		}
		y.parent = x.parent;
		if (x.parent == null) {
			this.root = y;
		} else if (x == x.parent.left) {
			x.parent.left = y;
		} else {
			x.parent.right = y;
		}
		y.left = x;
		x.parent = y;
	}

	// rotate right at node x
	public void rightRotate(RBTNode x) {
		RBTNode y = x.left;
		x.left = y.right;
		if (y.right != nil) {
			y.right.parent = x;
		}
		y.parent = x.parent;
		if (x.parent == null) {
			this.root = y;
		} else if (x == x.parent.right) {
			x.parent.right = y;
		} else {
			x.parent.left = y;
		}
		y.right = x;
		x.parent = y;
	}

	// insert the key to the tree in its appropriate position
	// and fix the tree


	public RBTNode getRoot(){
		return this.root;
	}

	// delete the node from the tree
	public void deleteNode(int key) {
		deleteNodeHelper(this.root, key);
	}

	// print the tree structure on the screen
	public void prettyPrint() {
        printHelper(this.root, "", true);
    }
    

	private int heightRec(RBTNode root) { // https://stackoverflow.com/questions/2597637/finding-height-in-binary-search-tree
		if (root == null) {
			return -1;
		}

		int lefth = heightRec(root.left);
		int righth = heightRec(root.right);

		if (lefth > righth) {
			return lefth + 1;
		} else {
			return righth + 1;
		}
	}


	private int BlackHeight(RBTNode root) {

		if (root == nil) {
			return 1;
		}

		int leftBlackHeight = BlackHeight(root.left);

		if (leftBlackHeight == 0) {
			return leftBlackHeight;
		}

		int rightBlackHeight = BlackHeight(root.right);

		if (rightBlackHeight == 0) {
			return rightBlackHeight;
		}

		if (leftBlackHeight != rightBlackHeight) {
			return 0;
		}
		else {
			return leftBlackHeight;
		}
	}

	private boolean redViolation() {

		if (root.color == true){
			return false;
		}


		return redViolationRec(root);
		
	}
	private boolean redViolationRec(RBTNode root) {
		
		if (!(root.color == true && root.parent.color == true)) {

			if (root.left != nil && root.right == nil) {
				redViolationRec(root.left);
			}

			if (root.right != nil && root.left == nil) {
				redViolationRec(root.right);
			}

			if (root.right != nil && root.left != nil) {
			
				redViolationRec(root.left);
				redViolationRec(root.right);

			}
			return true;
		}
		else {
			return false;
		}
			
	}

}


